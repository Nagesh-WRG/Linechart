<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\servers;
use Khill\Lavacharts\Lavacharts;
use DB;

class ServerController extends Controller
{
	public function jsondata($link)
	{
		$ch = curl_init();
		// Disable SSL verification
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		// Will return the response, if false it print the response
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		// Set the url
		curl_setopt($ch, CURLOPT_URL,$link);
		// Execute
		$result=curl_exec($ch);
		// Closing
		curl_close($ch);

		// Will dump a beauty json :3
		$result= json_decode($result, true);
		return $result;
	}


    public function readServer()
    {
    	$url= "http://www.sublimegroup.net/st4ts/data/get/type/servers/";

    	$result= $this->jsondata($url);

		return view('welcome')->with('result',$result);
    }


    public function formSubmit(Request $request)
    {
    	$server_name= $request->get('select_server');

    	$url= "http://www.sublimegroup.net/st4ts/data/get/type/iq/server/";
    	$url .= $server_name;
    	$url .= "/";

		$result= $this->jsondata($url);

		$server= servers::truncate();
		
		for($i=0;$i<count($result);$i++){

			$server = Servers::create([
				'data_value' => $result[$i]['data_value'],
				'data_label' => $result[$i]['data_label'],
			]);
		}

		$max = DB::select('select data_label, MAX(data_value) from servers');
		$min = DB::select('select data_label, MIN(data_value) from servers');
		

		$array= array_column($result,'data_value');
		$minval= min($array);
		$maxval= max($array);
		$average= array_sum($array)/count($array);



		$value= \Lava::DataTable();

		$data= servers::select("data_label as 0","data_value as 1")->get()->toArray();

		$value->addStringColumn('Label')
				->addNumberColumn('Value')
				->addRows($data);

		$chart['server_data']= \Lava::LineChart('server_data',$value);

		return view('chart',$chart)->with('min',$min)->with('max',$max)
									->with('average',$average)->with('server',$server_name)
									->with('minval',$minval)->with('maxval',$maxval);
    }
}
